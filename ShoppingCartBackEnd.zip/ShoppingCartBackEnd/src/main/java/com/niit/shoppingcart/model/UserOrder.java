
package com.niit.shoppingcart.model;


import javax.persistence.*;

@Entity
public class UserOrder {



    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    private int UserOrderId;

    @OneToOne
    @JoinColumn(name = "ID")
    private UserDetails user;

    
    private String billingAddress;

    
    private String shippingAddress;
    
    
    private String pay_type;

	public String getPay_type() {
		return pay_type;
	}

	public void setPay_type(String pay_type) {
		this.pay_type = pay_type;
	}

	public int getUserOrderId() {
		return UserOrderId;
	}

	public void setUserOrderId(int userOrderId) {
		UserOrderId = userOrderId;
	}

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails userDetails) {
		this.user = userDetails;
	}

	public String getBillingAddress() {
		return billingAddress;
	}

	public void setBillingAddress(String billingAddress) {
		this.billingAddress = billingAddress;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

   
} // The End of Class;





