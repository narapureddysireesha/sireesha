package com.niit.shoppingcart.dao;

import java.util.List;


import com.niit.shoppingcart.model.UserDetails;



public interface UserDAO {


	public List<UserDetails> list();

	public UserDetails get(String loggedInUser_ID);

	//public void saveOrUpdate(User user);
	
	public void saveOrUpdate(UserDetails userDetails);

	public void delete(String id);
	
	public boolean isValidUser(String id, String password);


}
